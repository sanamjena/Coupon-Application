Welcome to Coupon Application

Coupon Application is an application capable of generating the best and up to date coupons from various websites in order to gain a hassle free and save money.

Here's a quick intro as to how it works:

1. npm install
2. npm run seed
3. npm start

Thats it! visit https://localhost:3000 and the application is up and running!
